﻿using Microsoft.AspNetCore.Mvc;

namespace MiPrimeraWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductosController : ControllerBase
    {
        // Lista en memoria para el ejemplo
        private static List<Producto> productos = new List<Producto>
        {
            new Producto { Id = 1, Nombre = "Laptop", Precio = 15000 },
            new Producto { Id = 2, Nombre = "Mouse", Precio = 500 },
            new Producto { Id = 3, Nombre = "Teclado", Precio = 800 }
        };

        // GET: api/productos
        [HttpGet]
        public ActionResult<IEnumerable<Producto>> GetProductos()
        {
            return Ok(productos);
        }

        // GET: api/productos/1
        [HttpGet("{id}")]
        public ActionResult<Producto> GetProducto(int id)
        {
            var producto = productos.FirstOrDefault(p => p.Id == id);

            if (producto == null)
            {
                return NotFound($"Producto con ID {id} no encontrado");
            }

            return Ok(producto);
        }

        // POST: api/productos
        [HttpPost]
        public ActionResult<Producto> CreateProducto(Producto producto)
        {
            if (producto == null)
            {
                return BadRequest("El producto no puede ser nulo");
            }

            // Generar nuevo ID
            producto.Id = productos.Max(p => p.Id) + 1;
            productos.Add(producto);

            return CreatedAtAction(nameof(GetProducto), new { id = producto.Id }, producto);
        }

        // PUT: api/productos/1
        [HttpPut("{id}")]
        public IActionResult UpdateProducto(int id, Producto producto)
        {
            var productoExistente = productos.FirstOrDefault(p => p.Id == id);

            if (productoExistente == null)
            {
                return NotFound($"Producto con ID {id} no encontrado");
            }

            productoExistente.Nombre = producto.Nombre;
            productoExistente.Precio = producto.Precio;

            return Ok(productoExistente);
        }

        // DELETE: api/productos/1
        [HttpDelete("{id}")]
        public IActionResult DeleteProducto(int id)
        {
            var producto = productos.FirstOrDefault(p => p.Id == id);

            if (producto == null)
            {
                return NotFound($"Producto con ID {id} no encontrado");
            }

            productos.Remove(producto);
            return NoContent();
        }
    }

    // Modelo de datos
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
    }
}